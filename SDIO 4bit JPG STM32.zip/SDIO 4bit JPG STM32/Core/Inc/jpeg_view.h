#ifndef INC_JPEG_VIEW_H_
#define INC_JPEG_VIEW_H_

void jpeg_screen_view(char* path, char* fn, int px, int py, UINT *iw, UINT *ih);


#endif /* INC_JPEG_VIEW_H_ */
